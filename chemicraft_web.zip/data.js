const items=[
  {sym:'H',name:'Hydrogen',emoji:'💧',category:'Elements',unlocked:true},
  {sym:'O',name:'Oxygen',emoji:'🌬️',category:'Elements',unlocked:true},
  {sym:'C',name:'Carbon',emoji:'🪵',category:'Elements',unlocked:true},
  {sym:'N',name:'Nitrogen',emoji:'💨',category:'Elements',unlocked:true}
];
const recipes=[
  {inputs:['H','O'],output:'H2O'},
  {inputs:['C','O'],output:'CO2'},
  {inputs:['N','H'],output:'NH3'},
  {inputs:['C','H'],output:'CH4'}
];